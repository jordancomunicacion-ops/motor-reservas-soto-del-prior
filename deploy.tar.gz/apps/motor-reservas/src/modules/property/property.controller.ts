import { Controller, Get, Post, Body, Param, Patch, Delete } from '@nestjs/common';
import { PropertyService } from './property.service';

@Controller('property')
export class PropertyController {
    constructor(private readonly propertyService: PropertyService) { }

    @Post('hotels')
    createHotel(@Body() body: { name: string; currency: string; timezone: string }) {
        return this.propertyService.createHotel(body);
    }

    @Get('hotels')
    getHotels() {
        return this.propertyService.getHotels();
    }

    @Get('hotels/:id')
    getHotel(@Param('id') id: string) {
        return this.propertyService.getHotel(id);
    }

    @Patch('hotels/:id')
    updateHotel(@Param('id') id: string, @Body() body: any) {
        return this.propertyService.updateHotel(id, body);
    }

    @Delete('hotels/:id')
    deleteHotel(@Param('id') id: string) {
        return this.propertyService.deleteHotel(id);
    }

    @Post('hotels/:id/room-types')
    createRoomType(
        @Param('id') hotelId: string,
        @Body() body: any,
    ) {
        return this.propertyService.createRoomType(hotelId, body);
    }

    @Patch('room-types/:id')
    updateRoomType(@Param('id') id: string, @Body() body: any) {
        return this.propertyService.updateRoomType(id, body);
    }

    @Delete('room-types/:id')
    deleteRoomType(@Param('id') id: string) {
        return this.propertyService.deleteRoomType(id);
    }

    @Get('hotels/:id/room-types')
    getRoomTypes(@Param('id') hotelId: string) {
        return this.propertyService.getRoomTypes(hotelId);
    }

    @Post('room-types/:id/rooms')
    createRoom(@Param('id') roomTypeId: string, @Body('name') name: string) {
        return this.propertyService.createRoom(roomTypeId, name);
    }
}
