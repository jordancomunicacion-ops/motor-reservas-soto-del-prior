SELECT count(*) FROM "ResBooking";
